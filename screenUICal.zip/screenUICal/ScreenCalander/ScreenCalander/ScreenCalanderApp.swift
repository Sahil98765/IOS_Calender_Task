//
//  ScreenCalanderApp.swift
//  ScreenCalander
//
//  Created by Global on 09/05/24.
//

import SwiftUI

@main
struct ScreenCalanderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
