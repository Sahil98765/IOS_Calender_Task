//
//  ContentView.swift
//  ScreenCalander
//
//  Created by Global on 09/05/24.
//

import SwiftUI

struct ContentView: View {
    @State private var selectedDate: Date = Date()
    @State private var taskText: String = ""
    @State private var tasks: [String: [String]] = [:]
    
    var body: some View {
        VStack {
            HStack{Text("TO-DO")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .padding()
                    .bold()
                Spacer()
            }
            DatePicker("",selection: $selectedDate, displayedComponents: .date)
                .datePickerStyle(GraphicalDatePickerStyle())
                .padding()
            
            
            TextField("Pending Task", text: $taskText)
                .padding()
            TextField("Completed Task", text: $taskText)
                .padding()
            
            Button("New Task", action: NewTask)
                .padding()
                .bold()
        }
        if let taskForDate = tasks[dateformatter.string(from: selectedDate)]{
            VStack(alignment: .leading, content: {
                Text("New Task:")
            })
                .font(.headline)
            ForEach(taskForDate, id: \.self){ task in
                Text("_\(task)")
       
            }
        }
    }
    private let dateformatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .none
        return formatter
    }()
    
    private func NewTask(){
        let dateString = dateformatter.string(from: selectedDate)
        if var PendingTask = tasks[dateString]{
            PendingTask.append(taskText)
            tasks[dateString] = PendingTask
        } else {
            tasks[dateString] = [taskText]
        }
        taskText = ""
    }
    
    struct CalendarView_Previews: PreviewProvider{
        static var previews: some View{
            ContentView()
        }
    }
}

